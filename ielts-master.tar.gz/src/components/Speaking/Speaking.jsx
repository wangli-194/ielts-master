import { useState, useRef, useEffect } from "react";
import { useStore } from "../../store";
import { callClaudeStream, scoreSpeaking, EXAMINER_SYSTEM } from "../../utils/api";
import { getPhase, getTodayTasks } from "../../utils/tasks";
import { Card, Btn, ScoreDimBar, Spinner } from "../ui";

const PARTS = [
  { value: 1, label: "Part 1 — 日常问答" },
  { value: 2, label: "Part 2 — 长段独白" },
  { value: 3, label: "Part 3 — 抽象讨论" },
];

const TOPICS = [
  "日常生活与习惯", "家乡与居住环境", "科技对社会的影响",
  "环境保护", "教育体制", "城市化与农村发展", "全球化",
  "人工智能的未来", "医疗与公共健康", "文化多样性",
];

export default function Speaking() {
  const { state, dispatch } = useStore();
  const phase = getPhase(state.currentDay);

  const [part, setPart] = useState(Math.min(phase, 3));
  const [topic, setTopic] = useState(TOPICS[0]);
  const [messages, setMessages] = useState([]);   // { role, content }
  const [input, setInput] = useState("");
  const [streaming, setStreaming] = useState(false);
  const [scoring, setScoring] = useState(false);
  const [scoreResult, setScoreResult] = useState(null);
  const [recording, setRecording] = useState(false);
  const [sessionStarted, setSessionStarted] = useState(false);

  const chatRef = useRef(null);
  const recRef = useRef(null);   // SpeechRecognition instance

  // Auto-scroll chat
  useEffect(() => {
    if (chatRef.current) chatRef.current.scrollTop = chatRef.current.scrollHeight;
  }, [messages]);

  async function startSession() {
    setMessages([]);
    setScoreResult(null);
    setSessionStarted(true);
    await sendExaminer([], `Start the Part ${part} interview on the topic "${topic}". Ask your first question.`);
  }

  async function sendExaminer(history, userMsg) {
    const updated = userMsg
      ? [...history, { role: "user", content: userMsg }]
      : history;

    setStreaming(true);
    let reply = "";
    const systemPrompt = EXAMINER_SYSTEM(part, topic);

    try {
      await callClaudeStream(
        updated,
        systemPrompt,
        (chunk) => {
          reply += chunk;
          setMessages((prev) => {
            const last = prev[prev.length - 1];
            if (last?.role === "assistant" && last.streaming) {
              return [...prev.slice(0, -1), { role: "assistant", content: reply, streaming: true }];
            }
            return [...prev, { role: "assistant", content: reply, streaming: true }];
          });
        }
      );
      setMessages((prev) =>
        prev.map((m, i) => i === prev.length - 1 ? { ...m, streaming: false } : m)
      );
    } catch (e) {
      setMessages((prev) => [...prev, { role: "assistant", content: `⚠️ 连接失败：${e.message}` }]);
    } finally {
      setStreaming(false);
    }

    return reply;
  }

  async function handleSend() {
    if (!input.trim() || streaming) return;
    const userContent = input.trim();
    setInput("");
    const updated = [...messages, { role: "user", content: userContent }];
    setMessages(updated);
    await sendExaminer(updated, null);
  }

  async function handleScore() {
    if (messages.length < 2) return;
    setScoring(true);
    const transcript = messages
      .map((m) => `${m.role === "user" ? "候选人" : "考官"}: ${m.content}`)
      .join("\n");
    const result = await scoreSpeaking(transcript);
    setScoreResult(result);
    setScoring(false);

    if (result) {
      dispatch({
        type: "ADD_SPEAKING_SESSION",
        session: {
          date: new Date().toISOString().split("T")[0],
          part,
          topic,
          scores: result,
        },
      });
      dispatch({ type: "COMPLETE_TASK", id: "speaking_practice" });
    }
  }

  // Web Speech API
  function toggleRecording() {
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SpeechRecognition) {
      alert("您的浏览器不支持语音识别，请使用 Chrome 或 Edge");
      return;
    }
    if (recording) {
      recRef.current?.stop();
      setRecording(false);
      return;
    }
    const rec = new SpeechRecognition();
    rec.lang = "en-US";
    rec.interimResults = true;
    rec.onresult = (e) => {
      const t = Array.from(e.results).map((r) => r[0].transcript).join("");
      setInput(t);
    };
    rec.onend = () => setRecording(false);
    rec.start();
    recRef.current = rec;
    setRecording(true);
  }

  const DIM_COLORS = { fluency: "#534AB7", lexical: "#185FA5", grammar: "#1D9E75", pronunciation: "#BA7517" };

  return (
    <div style={{ padding: "1.5rem", display: "flex", flexDirection: "column", height: "100%" }}>
      {/* Header */}
      <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: "1rem", flexWrap: "wrap" }}>
        <span style={{ fontSize: 14, fontWeight: 500, color: "var(--color-text-primary)" }}>口语模拟 — AI考官对话</span>
        <select
          value={part}
          onChange={(e) => setPart(Number(e.target.value))}
          style={{ fontSize: 12, padding: "3px 8px", borderRadius: "var(--border-radius-md)", border: "0.5px solid var(--color-border-secondary)", background: "var(--color-background-secondary)", color: "var(--color-text-primary)" }}
        >
          {PARTS.map((p) => <option key={p.value} value={p.value}>{p.label}</option>)}
        </select>
        <select
          value={topic}
          onChange={(e) => setTopic(e.target.value)}
          style={{ fontSize: 12, padding: "3px 8px", borderRadius: "var(--border-radius-md)", border: "0.5px solid var(--color-border-secondary)", background: "var(--color-background-secondary)", color: "var(--color-text-primary)" }}
        >
          {TOPICS.map((t) => <option key={t} value={t}>{t}</option>)}
        </select>
        <div style={{ marginLeft: "auto", display: "flex", gap: 8 }}>
          <Btn onClick={startSession} primary>
            <i className="ti ti-player-play" /> {sessionStarted ? "重新开始" : "开始对话"}
          </Btn>
          {messages.length >= 4 && (
            <Btn onClick={handleScore} disabled={scoring}>
              {scoring ? <Spinner /> : <><i className="ti ti-chart-bar" /> 获取评分</>}
            </Btn>
          )}
        </div>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "1fr 290px", gap: "1rem", flex: 1 }}>
        {/* Chat area */}
        <div style={{ display: "flex", flexDirection: "column", gap: 0 }}>
          <div
            ref={chatRef}
            style={{
              flex: 1, minHeight: 300, maxHeight: 420,
              overflowY: "auto",
              background: "var(--color-background-primary)",
              border: "0.5px solid var(--color-border-tertiary)",
              borderRadius: "var(--border-radius-lg)",
              padding: "1rem",
              display: "flex", flexDirection: "column", gap: 12,
              marginBottom: 10,
            }}
          >
            {!sessionStarted && (
              <div style={{ color: "var(--color-text-tertiary)", fontSize: 13, textAlign: "center", margin: "auto" }}>
                选择考试部分和话题，点击「开始对话」
              </div>
            )}
            {messages.map((m, i) => (
              <div key={i} style={{
                maxWidth: "88%",
                alignSelf: m.role === "user" ? "flex-end" : "flex-start",
                background: m.role === "user" ? "#534AB7" : "#EEEDFE",
                color: m.role === "user" ? "#fff" : "#26215C",
                padding: "10px 14px",
                borderRadius: 12,
                borderBottomRightRadius: m.role === "user" ? 4 : 12,
                borderBottomLeftRadius: m.role === "user" ? 12 : 4,
                fontSize: 13.5,
                lineHeight: 1.6,
              }}>
                {m.content}
                {m.streaming && <span style={{ opacity: 0.5 }}>▋</span>}
              </div>
            ))}
          </div>

          {/* Input row */}
          <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
            <button
              onClick={toggleRecording}
              style={{
                width: 44, height: 44, borderRadius: "50%",
                background: recording ? "#E24B4A" : "#534AB7",
                border: "none", cursor: "pointer",
                display: "flex", alignItems: "center", justifyContent: "center",
                color: "#fff", fontSize: 20,
                animation: recording ? "pulse 1s infinite" : "none",
                flexShrink: 0,
              }}
              aria-label={recording ? "停止录音" : "开始录音"}
            >
              <i className={`ti ti-microphone${recording ? "-off" : ""}`} />
            </button>
            <input
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && !e.shiftKey && handleSend()}
              placeholder={recording ? "聆听中..." : "输入或语音作答..."}
              style={{
                flex: 1, padding: "8px 12px",
                border: "0.5px solid var(--color-border-secondary)",
                borderRadius: "var(--border-radius-md)",
                background: "var(--color-background-primary)",
                color: "var(--color-text-primary)",
                fontSize: 13, outline: "none",
              }}
            />
            <Btn primary onClick={handleSend} disabled={!input.trim() || streaming}>
              发送 <i className="ti ti-arrow-right" />
            </Btn>
          </div>
          <style>{`@keyframes pulse{0%,100%{box-shadow:0 0 0 0 rgba(226,75,74,.4)}50%{box-shadow:0 0 0 8px rgba(226,75,74,0)}}`}</style>
        </div>

        {/* Score panel */}
        <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
          <div style={{ fontSize: 13, fontWeight: 500, color: "var(--color-text-primary)" }}>评分报告</div>
          {scoreResult ? (
            <>
              <div style={{ background: "#EEEDFE", borderRadius: "var(--border-radius-md)", padding: "0.75rem", textAlign: "center" }}>
                <div style={{ fontSize: 11, color: "#534AB7", marginBottom: 4 }}>综合评分</div>
                <div style={{ fontSize: 36, fontWeight: 500, color: "#3C3489" }}>{scoreResult.overall}</div>
              </div>
              <ScoreDimBar name="流利度 Fluency" score={scoreResult.fluency?.score || 0} color={DIM_COLORS.fluency} />
              <ScoreDimBar name="词汇多样性 Lexical" score={scoreResult.lexical?.score || 0} color={DIM_COLORS.lexical} />
              <ScoreDimBar name="语法准确度 Grammar" score={scoreResult.grammar?.score || 0} color={DIM_COLORS.grammar} />
              <ScoreDimBar name="发音 Pronunciation" score={scoreResult.pronunciation?.score || 0} color={DIM_COLORS.pronunciation} />
              {scoreResult.lexical?.suggestions?.length > 0 && (
                <div style={{ background: "#EEEDFE", borderRadius: "var(--border-radius-md)", padding: "0.75rem", fontSize: 12, color: "#26215C", lineHeight: 1.7 }}>
                  <strong>表达优化建议：</strong>
                  {scoreResult.lexical.suggestions.map((s, i) => <div key={i}>• {s}</div>)}
                </div>
              )}
              {scoreResult.grammar?.errors?.length > 0 && (
                <div style={{ background: "#FCEBEB", borderRadius: "var(--border-radius-md)", padding: "0.75rem", fontSize: 12, color: "#4A1B0C", lineHeight: 1.7 }}>
                  <strong>语法纠错：</strong>
                  {scoreResult.grammar.errors.map((e, i) => <div key={i}>• {e}</div>)}
                </div>
              )}
            </>
          ) : (
            <div style={{ color: "var(--color-text-tertiary)", fontSize: 12, lineHeight: 1.7 }}>
              完成至少 4 轮对话后，点击「获取评分」查看四维分析报告。
              {scoring && <div style={{ marginTop: 8 }}><Spinner /></div>}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
