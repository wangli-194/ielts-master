import { useState } from "react";
import { useStore } from "../../store";
import { sm2, getDueCards, createCard } from "../../utils/sm2";
import { Card, CardTitle, MetricCard, Btn, ProgressBar } from "../ui";

const RATING_BTNS = [
  { rating: 1, label: "不记得", sub: "1天后", bg: "#E24B4A", color: "#fff" },
  { rating: 3, label: "模糊", sub: "3天后", bg: "var(--color-background-secondary)", color: "#185FA5", border: "#185FA5" },
  { rating: 5, label: "记住了", sub: "7天+", bg: "#1D9E75", color: "#fff" },
];

// Demo seed cards for first-time users
const SEED_CARDS = [
  { word: "burgeoning", definition: "（形）迅速增长的，蓬勃发展的", phonetic: "/ˈbɜːdʒənɪŋ/", example: "The burgeoning tech industry created thousands of new jobs.", synonyms: "flourishing, thriving, expanding" },
  { word: "ramification", definition: "（名）后果，影响；支流，分支", phonetic: "/ˌræmɪfɪˈkeɪʃ(ə)n/", example: "The ramifications of the policy were felt across the country.", synonyms: "consequence, implication, outcome" },
  { word: "salient", definition: "（形）最重要的，最显著的", phonetic: "/ˈseɪliənt/", example: "The most salient feature of the report is its clarity.", synonyms: "notable, prominent, striking" },
  { word: "recirculation", definition: "（名）再循环，循环利用", phonetic: "/ˌriːˌsɜːkjʊˈleɪʃ(ə)n/", example: "Water recirculation reduces waste significantly.", synonyms: "recycling, reuse, circulation" },
  { word: "impediment", definition: "（名）障碍，阻碍", phonetic: "/ɪmˈpedɪmənt/", example: "Lack of funding is the main impediment to progress.", synonyms: "obstacle, barrier, hindrance" },
];

export default function Vocab() {
  const { state, dispatch } = useStore();
  const [revealed, setRevealed] = useState(false);
  const [cardIndex, setCardIndex] = useState(0);
  const [addWord, setAddWord] = useState("");
  const [addDef, setAddDef] = useState("");

  // Seed on first use
  const allCards = state.vocabCards.length === 0
    ? SEED_CARDS.map((s) => createCard(s.word, s.definition, "内置词库"))
    : state.vocabCards;

  const dueCards = getDueCards(allCards);
  const currentCard = dueCards[cardIndex % Math.max(dueCards.length, 1)];
  const seedCard = allCards.find((c) => c.word === currentCard?.word) || currentCard;
  const seedMeta = SEED_CARDS.find((s) => s.word === currentCard?.word);

  function rate(rating) {
    if (!currentCard) return;
    const updated = sm2(currentCard, rating);
    dispatch({ type: "UPDATE_VOCAB_CARD", card: updated });
    setRevealed(false);
    // Advance to next due card
    const next = (cardIndex + 1) % Math.max(dueCards.length, 1);
    setCardIndex(next);
    if (next === 0) dispatch({ type: "COMPLETE_TASK", id: "vocab_review" });
  }

  function addManual() {
    if (!addWord.trim() || !addDef.trim()) return;
    const card = createCard(addWord.trim(), addDef.trim(), "手动添加");
    dispatch({ type: "ADD_VOCAB_CARDS", cards: [card] });
    setAddWord(""); setAddDef("");
  }

  const mastered = state.vocabCards.filter((c) => c.reps >= 3).length;
  const progressPct = dueCards.length === 0 ? 100 : Math.round(((cardIndex % (dueCards.length + 1)) / dueCards.length) * 100);

  return (
    <div style={{ padding: "1.5rem" }}>
      {/* Header */}
      <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: "1rem", flexWrap: "wrap" }}>
        <span style={{ fontSize: 14, fontWeight: 500, color: "var(--color-text-primary)" }}>词汇记忆 — 间隔重复 SRS</span>
        <span style={{ fontSize: 12, color: "var(--color-text-secondary)" }}>
          今日待复习 {dueCards.length} 张 · 已完成 {cardIndex % (dueCards.length + 1)}
        </span>
        <div style={{ marginLeft: "auto", width: 120 }}>
          <ProgressBar value={cardIndex % (dueCards.length + 1)} max={Math.max(dueCards.length, 1)} />
        </div>
      </div>

      {/* SRS Card */}
      {dueCards.length === 0 ? (
        <Card style={{ textAlign: "center", padding: "2rem" }}>
          <i className="ti ti-circle-check" style={{ fontSize: 40, color: "#1D9E75" }} aria-hidden />
          <div style={{ fontSize: 16, fontWeight: 500, color: "var(--color-text-primary)", margin: "1rem 0 0.5rem" }}>今日词汇全部复习完毕！</div>
          <div style={{ fontSize: 13, color: "var(--color-text-secondary)" }}>继续阅读训练，将新生词加入词库</div>
        </Card>
      ) : (
        <Card style={{ textAlign: "center" }}>
          <div style={{ fontSize: 11, color: "var(--color-text-tertiary)", marginBottom: "0.75rem" }}>
            来源：{currentCard?.source || "词库"}
          </div>
          <div style={{ fontSize: 36, fontWeight: 500, color: "var(--color-text-primary)", marginBottom: "0.5rem" }}>
            {currentCard?.word}
          </div>
          {seedMeta?.phonetic && (
            <div style={{ fontSize: 14, color: "var(--color-text-secondary)", marginBottom: "1rem" }}>
              {seedMeta.phonetic}
            </div>
          )}
          <div style={{ fontSize: 13, color: "var(--color-text-secondary)", marginBottom: "1rem" }}>
            这个词的意思是什么？
          </div>

          {!revealed ? (
            <Btn onClick={() => setRevealed(true)} primary>
              <i className="ti ti-eye" /> 显示释义
            </Btn>
          ) : (
            <div>
              <div style={{ borderTop: "0.5px solid var(--color-border-tertiary)", margin: "1rem 0", paddingTop: "1rem" }}>
                <div style={{ fontSize: 18, fontWeight: 500, color: "var(--color-text-primary)", marginBottom: "0.5rem" }}>
                  {currentCard?.definition}
                </div>
                {seedMeta?.example && (
                  <div style={{ fontSize: 13, color: "var(--color-text-secondary)", fontStyle: "italic", lineHeight: 1.7, marginBottom: "0.5rem" }}>
                    {seedMeta.example}
                  </div>
                )}
                {seedMeta?.synonyms && (
                  <div style={{ fontSize: 12, color: "var(--color-text-tertiary)" }}>
                    近义词：{seedMeta.synonyms}
                  </div>
                )}
              </div>
              <div style={{ fontSize: 12, color: "var(--color-text-secondary)", marginBottom: "0.75rem" }}>记忆程度如何？</div>
              <div style={{ display: "flex", gap: 8, justifyContent: "center", flexWrap: "wrap" }}>
                {RATING_BTNS.map(({ rating, label, sub, bg, color, border }) => (
                  <button key={rating} onClick={() => rate(rating)}
                    style={{
                      padding: "7px 16px", borderRadius: "var(--border-radius-md)",
                      border: `0.5px solid ${border || bg}`,
                      background: bg, color, cursor: "pointer", fontSize: 13,
                    }}>
                    {label}
                    <div style={{ fontSize: 10, opacity: 0.8 }}>{sub}</div>
                  </button>
                ))}
              </div>
            </div>
          )}
        </Card>
      )}

      {/* Stats */}
      <div style={{ display: "grid", gridTemplateColumns: "repeat(3,1fr)", gap: 10, marginBottom: "1rem" }}>
        <MetricCard label="词库总量" value={allCards.length} sub={`已掌握 ${mastered} 词`} />
        <MetricCard label="今日待复习" value={dueCards.length} sub="张卡片" />
        <MetricCard label="连续打卡" value={`${state.vocabStreak || 1} 天`} sub="保持下去！" />
      </div>

      {/* Manual add */}
      <Card>
        <CardTitle icon="plus">手动添加单词</CardTitle>
        <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
          <input value={addWord} onChange={(e) => setAddWord(e.target.value)}
            placeholder="单词"
            style={{ flex: "1 1 120px", padding: "7px 10px", border: "0.5px solid var(--color-border-secondary)", borderRadius: "var(--border-radius-md)", background: "var(--color-background-primary)", color: "var(--color-text-primary)", fontSize: 13 }} />
          <input value={addDef} onChange={(e) => setAddDef(e.target.value)}
            placeholder="中文释义"
            style={{ flex: "2 1 200px", padding: "7px 10px", border: "0.5px solid var(--color-border-secondary)", borderRadius: "var(--border-radius-md)", background: "var(--color-background-primary)", color: "var(--color-text-primary)", fontSize: 13 }} />
          <Btn primary onClick={addManual} disabled={!addWord.trim() || !addDef.trim()}>
            <i className="ti ti-plus" /> 添加
          </Btn>
        </div>
      </Card>
    </div>
  );
}
