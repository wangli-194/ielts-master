const API_URL = "https://api.anthropic.com/v1/messages";
const MODEL = "claude-sonnet-4-6";

/**
 * Base call — returns full response text
 */
export async function callClaude(messages, systemPrompt = "", maxTokens = 1000) {
  const body = {
    model: MODEL,
    max_tokens: maxTokens,
    system: systemPrompt,
    messages,
  };

  const res = await fetch(API_URL, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });

  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err?.error?.message || `API error ${res.status}`);
  }

  const data = await res.json();
  return data.content.map((b) => b.text || "").join("");
}

/**
 * Streaming call — onChunk(text) called per token
 */
export async function callClaudeStream(messages, systemPrompt = "", onChunk, maxTokens = 1000) {
  const body = {
    model: MODEL,
    max_tokens: maxTokens,
    system: systemPrompt,
    stream: true,
    messages,
  };

  const res = await fetch(API_URL, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "anthropic-version": "2023-06-01",
    },
    body: JSON.stringify(body),
  });

  if (!res.ok) throw new Error(`API error ${res.status}`);

  const reader = res.body.getReader();
  const decoder = new TextDecoder();
  let buffer = "";

  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    buffer += decoder.decode(value, { stream: true });

    const lines = buffer.split("\n");
    buffer = lines.pop();

    for (const line of lines) {
      if (!line.startsWith("data: ")) continue;
      const json = line.slice(6);
      if (json === "[DONE]") return;
      try {
        const parsed = JSON.parse(json);
        const text = parsed?.delta?.text;
        if (text) onChunk(text);
      } catch (_) {}
    }
  }
}

// ── Prompts ─────────────────────────────────────────────────────────────────

export const EXAMINER_SYSTEM = (part, topic) => `
You are a strict but encouraging IELTS speaking examiner conducting a Part ${part} interview.
Topic: ${topic}

Rules:
- Ask ONE question at a time, naturally and conversationally
- Part 1: simple personal questions (30s answers)
- Part 2: give a cue card task, allow 1 min prep, then ask for 1-2 min talk
- Part 3: abstract, analytical follow-up questions
- Keep your turns SHORT (1-2 sentences max)
- After 6 exchanges, say "Thank you, that's the end of Part ${part}."
- Do NOT give scores or feedback during the conversation — that comes separately
`.trim();

export const SCORING_SYSTEM = `
You are an expert IELTS examiner. Analyze the candidate's speaking and return ONLY valid JSON.
Score each dimension 1.0–9.0 in 0.5 increments.
`.trim();

export async function scoreSpeaking(transcript) {
  const prompt = `
Analyze this IELTS speaking transcript and return ONLY a JSON object with this exact shape:
{
  "overall": 4.5,
  "fluency": { "score": 4.5, "comment": "...", "tip": "..." },
  "lexical": { "score": 4.0, "comment": "...", "tip": "...", "suggestions": ["original phrase → better phrase"] },
  "grammar": { "score": 4.0, "comment": "...", "tip": "...", "errors": ["error → correction"] },
  "pronunciation": { "score": 4.5, "comment": "...", "tip": "..." }
}

Transcript:
${transcript}
`.trim();

  const raw = await callClaude(
    [{ role: "user", content: prompt }],
    SCORING_SYSTEM,
    800
  );

  try {
    return JSON.parse(raw.replace(/```json|```/g, "").trim());
  } catch {
    return null;
  }
}

export async function lookupWord(word) {
  const prompt = `
For the word "${word}", return ONLY valid JSON:
{
  "word": "${word}",
  "phonetic": "/..../",
  "partOfSpeech": "adjective",
  "definition": "Chinese definition here",
  "definitionEn": "English definition here",
  "example": "IELTS-level example sentence",
  "synonyms": ["word1", "word2", "word3"],
  "ieltsBand": 7
}
`.trim();

  const raw = await callClaude(
    [{ role: "user", content: prompt }],
    "You are an IELTS vocabulary expert. Return ONLY valid JSON, no markdown.",
    400
  );

  try {
    return JSON.parse(raw.replace(/```json|```/g, "").trim());
  } catch {
    return { word, definition: "查询失败，请重试" };
  }
}
