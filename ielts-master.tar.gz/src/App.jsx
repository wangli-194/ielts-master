import { useState } from "react";
import Layout from "./components/Layout/Layout";
import Dashboard from "./components/Dashboard/Dashboard";
import Speaking from "./components/Speaking/Speaking";
import Reading from "./components/Reading/Reading";
import Vocab from "./components/Vocab/Vocab";
import Progress from "./components/Progress/Progress";

export default function App() {
  const [currentView, setCurrentView] = useState("dashboard");

  const views = {
    dashboard: <Dashboard onNavigate={setCurrentView} />,
    speaking: <Speaking />,
    reading: <Reading />,
    vocab: <Vocab />,
    progress: <Progress />,
  };

  return (
    <Layout currentView={currentView} onNavigate={setCurrentView}>
      {views[currentView]}
    </Layout>
  );
}
