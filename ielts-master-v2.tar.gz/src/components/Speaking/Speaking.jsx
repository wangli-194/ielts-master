import { useState, useRef, useEffect, useCallback } from "react";
import { useStore } from "../../store";
import { callClaudeStream, scoreSpeaking, EXAMINER_SYSTEM } from "../../utils/api";
import { speak, stopSpeaking, initTTS, ttsSupported, getAvailableVoices, setVoice } from "../../utils/tts";
import { useASR } from "../../hooks/useASR";
import { getPhase } from "../../utils/tasks";
import { Card, Btn, ScoreDimBar, Spinner } from "../ui";

const PARTS = [
  { value: 1, label: "Part 1 — 日常问答" },
  { value: 2, label: "Part 2 — 长段独白" },
  { value: 3, label: "Part 3 — 抽象讨论" },
];

const TOPICS = [
  "Daily life and habits", "Hometown and environment", "Technology and society",
  "Environmental protection", "Education systems", "Urbanisation",
  "Globalisation", "Artificial intelligence", "Healthcare", "Cultural diversity",
];

export default function Speaking() {
  const { state, dispatch } = useStore();
  const phase = getPhase(state.currentDay);

  const [part, setPart]           = useState(Math.min(phase, 3));
  const [topic, setTopic]         = useState(TOPICS[0]);
  const [messages, setMessages]   = useState([]);
  const [input, setInput]         = useState("");
  const [streaming, setStreaming] = useState(false);
  const [examinerSpeaking, setExaminerSpeaking] = useState(false);
  const [scoring, setScoring]     = useState(false);
  const [scoreResult, setScoreResult] = useState(null);
  const [sessionStarted, setSessionStarted] = useState(false);
  const [ttsEnabled, setTtsEnabled]   = useState(true);
  const [voices, setVoices]       = useState([]);
  const [selectedVoice, setSelectedVoice] = useState("");
  const [sessionEnded, setSessionEnded] = useState(false);

  const chatRef = useRef(null);

  // Init TTS
  useEffect(() => {
    initTTS().then(() => {
      const v = getAvailableVoices();
      setVoices(v);
      if (v.length) setSelectedVoice(v[0].name);
    });
    return () => stopSpeaking();
  }, []);

  // Auto-scroll
  useEffect(() => {
    if (chatRef.current) chatRef.current.scrollTop = chatRef.current.scrollHeight;
  }, [messages]);

  // ASR: when user finishes speaking, auto-fill input
  const { transcript, interimTranscript, listening, supported: asrSupported, start: startASR, stop: stopASR, reset: resetASR } = useASR({
    onFinal: (text) => setInput(text),
    lang: "en-US",
  });

  function handleVoiceChange(name) {
    setSelectedVoice(name);
    setVoice(name);
  }

  async function startSession() {
    stopSpeaking();
    setMessages([]);
    setScoreResult(null);
    setSessionEnded(false);
    setSessionStarted(true);
    setInput("");
    resetASR();
    await examinerTurn([], `Start the Part ${part} IELTS interview on the topic: "${topic}". Ask your first question now.`);
  }

  async function examinerTurn(history, userMsg) {
    const updated = userMsg
      ? [...history, { role: "user", content: userMsg }]
      : history;

    setStreaming(true);
    let reply = "";

    try {
      await callClaudeStream(
        updated,
        EXAMINER_SYSTEM(part, topic),
        (chunk) => {
          reply += chunk;
          setMessages((prev) => {
            const last = prev[prev.length - 1];
            if (last?.role === "assistant" && last.streaming) {
              return [...prev.slice(0, -1), { role: "assistant", content: reply, streaming: true }];
            }
            return [...prev, { role: "assistant", content: reply, streaming: true }];
          });
        },
        300
      );

      // Mark streaming done
      setMessages((prev) =>
        prev.map((m, i) => i === prev.length - 1 ? { ...m, streaming: false } : m)
      );

      // Detect session end
      if (reply.toLowerCase().includes("end of part")) {
        setSessionEnded(true);
      }

      // Speak examiner reply
      if (ttsEnabled && ttsSupported() && reply) {
        setExaminerSpeaking(true);
        speak(reply, {
          rate: 0.90,
          pitch: 0.95,
          onEnd: () => setExaminerSpeaking(false),
          onError: () => setExaminerSpeaking(false),
        });
      }
    } catch (e) {
      setMessages((prev) => [...prev, { role: "assistant", content: `⚠️ 错误：${e.message}` }]);
    } finally {
      setStreaming(false);
    }

    return reply;
  }

  async function handleSend() {
    const content = input.trim();
    if (!content || streaming || examinerSpeaking) return;
    stopSpeaking();
    setExaminerSpeaking(false);
    setInput("");
    resetASR();
    const updated = [...messages, { role: "user", content }];
    setMessages(updated);
    await examinerTurn(updated, null);
  }

  function handleMicToggle() {
    if (listening) {
      stopASR();
    } else {
      stopSpeaking();
      setExaminerSpeaking(false);
      resetASR();
      startASR();
    }
  }

  async function handleScore() {
    setScoring(true);
    stopSpeaking();
    const transcript = messages
      .map((m) => `${m.role === "user" ? "Candidate" : "Examiner"}: ${m.content}`)
      .join("\n");
    const result = await scoreSpeaking(transcript);
    setScoreResult(result);
    setScoring(false);
    if (result) {
      dispatch({
        type: "ADD_SPEAKING_SESSION",
        session: { date: new Date().toISOString().split("T")[0], part, topic, scores: result },
      });
      dispatch({ type: "COMPLETE_TASK", id: "speaking_practice" });
    }
  }

  const DIM_COLORS = {
    fluency: "#534AB7", lexical: "#185FA5", grammar: "#1D9E75", pronunciation: "#BA7517",
  };

  const canSend = input.trim() && !streaming && !examinerSpeaking;
  const canScore = messages.filter(m => m.role === "user").length >= 3;

  return (
    <div style={{ padding: "1.5rem", display: "flex", flexDirection: "column", gap: "1rem" }}>
      {/* Controls row */}
      <div style={{ display: "flex", alignItems: "center", gap: 10, flexWrap: "wrap" }}>
        <span style={{ fontSize: 14, fontWeight: 500, color: "var(--color-text-primary)" }}>
          口语模拟 — AI 考官对话
        </span>

        <select value={part} onChange={(e) => setPart(Number(e.target.value))}
          style={selectStyle}>
          {PARTS.map(p => <option key={p.value} value={p.value}>{p.label}</option>)}
        </select>

        <select value={topic} onChange={(e) => setTopic(e.target.value)}
          style={{ ...selectStyle, maxWidth: 200 }}>
          {TOPICS.map(t => <option key={t} value={t}>{t}</option>)}
        </select>

        {/* TTS toggle + voice */}
        {ttsSupported() && (
          <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
            <button onClick={() => { setTtsEnabled(v => !v); if (ttsEnabled) stopSpeaking(); }}
              style={{ background: "none", border: "none", cursor: "pointer", fontSize: 18, color: ttsEnabled ? "#534AB7" : "var(--color-text-tertiary)" }}
              title={ttsEnabled ? "关闭考官朗读" : "开启考官朗读"}
              aria-label="切换考官朗读">
              <i className={`ti ti-volume${ttsEnabled ? "" : "-off"}`} />
            </button>
            {ttsEnabled && voices.length > 1 && (
              <select value={selectedVoice} onChange={(e) => handleVoiceChange(e.target.value)}
                style={{ ...selectStyle, maxWidth: 140, fontSize: 11 }}>
                {voices.map(v => <option key={v.name} value={v.name}>{v.name.slice(0, 18)}</option>)}
              </select>
            )}
          </div>
        )}

        <div style={{ marginLeft: "auto", display: "flex", gap: 8 }}>
          <Btn onClick={startSession} primary disabled={streaming}>
            <i className={`ti ti-${sessionStarted ? "refresh" : "player-play"}`} />
            {sessionStarted ? "重开" : "开始对话"}
          </Btn>
          {canScore && (
            <Btn onClick={handleScore} disabled={scoring}>
              {scoring ? <Spinner /> : <><i className="ti ti-chart-bar" /> 评分</>}
            </Btn>
          )}
        </div>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "1fr 290px", gap: "1rem" }}>
        {/* Chat */}
        <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
          {/* Status bar */}
          {sessionStarted && (
            <div style={{ display: "flex", alignItems: "center", gap: 8, fontSize: 12, color: "var(--color-text-secondary)" }}>
              {examinerSpeaking && (
                <span style={{ display: "flex", alignItems: "center", gap: 5, color: "#534AB7" }}>
                  <SoundWave /> 考官朗读中...
                  <button onClick={() => { stopSpeaking(); setExaminerSpeaking(false); }}
                    style={{ background: "none", border: "none", cursor: "pointer", color: "#534AB7", fontSize: 12, padding: "0 2px" }}>
                    停止
                  </button>
                </span>
              )}
              {listening && (
                <span style={{ display: "flex", alignItems: "center", gap: 5, color: "#E24B4A" }}>
                  <i className="ti ti-microphone" style={{ fontSize: 14 }} /> 聆听中...
                </span>
              )}
              {sessionEnded && !scoreResult && (
                <span style={{ color: "#1D9E75" }}>
                  <i className="ti ti-check" style={{ marginRight: 4 }} />本轮结束 — 点击「评分」查看报告
                </span>
              )}
            </div>
          )}

          {/* Chat box */}
          <div ref={chatRef} style={{
            minHeight: 320, maxHeight: 420, overflowY: "auto",
            background: "var(--color-background-primary)",
            border: "0.5px solid var(--color-border-tertiary)",
            borderRadius: "var(--border-radius-lg)",
            padding: "1rem",
            display: "flex", flexDirection: "column", gap: 12,
          }}>
            {!sessionStarted && (
              <div style={{ color: "var(--color-text-tertiary)", fontSize: 13, textAlign: "center", margin: "auto", lineHeight: 2 }}>
                选择考试部分和话题<br />点击「开始对话」
              </div>
            )}
            {messages.map((m, i) => (
              <ChatBubble key={i} message={m} />
            ))}
          </div>

          {/* Input row */}
          <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
            {asrSupported && (
              <button onClick={handleMicToggle}
                style={{
                  width: 44, height: 44, borderRadius: "50%", flexShrink: 0,
                  background: listening ? "#E24B4A" : "#534AB7",
                  border: "none", cursor: "pointer", color: "#fff", fontSize: 20,
                  display: "flex", alignItems: "center", justifyContent: "center",
                  animation: listening ? "pulse 1s infinite" : "none",
                }}
                aria-label={listening ? "停止录音" : "开始录音"}>
                <i className={`ti ti-microphone${listening ? "-off" : ""}`} />
              </button>
            )}

            <div style={{ flex: 1, position: "relative" }}>
              <input
                value={listening && interimTranscript ? interimTranscript : input}
                onChange={(e) => !listening && setInput(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && !e.shiftKey && handleSend()}
                placeholder={listening ? "正在聆听..." : "输入或按麦克风回答..."}
                readOnly={listening}
                style={{
                  width: "100%", padding: "9px 12px",
                  border: `0.5px solid ${listening ? "#E24B4A" : "var(--color-border-secondary)"}`,
                  borderRadius: "var(--border-radius-md)",
                  background: "var(--color-background-primary)",
                  color: "var(--color-text-primary)",
                  fontSize: 13, outline: "none",
                }}
              />
            </div>

            <Btn primary onClick={handleSend} disabled={!canSend}>
              发送 <i className="ti ti-arrow-right" />
            </Btn>
          </div>
          <style>{`
            @keyframes pulse{0%,100%{box-shadow:0 0 0 0 rgba(226,75,74,.35)}50%{box-shadow:0 0 0 9px rgba(226,75,74,0)}}
          `}</style>
        </div>

        {/* Score panel */}
        <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
          <div style={{ fontSize: 13, fontWeight: 500, color: "var(--color-text-primary)" }}>评分报告</div>

          {scoring && <Spinner />}

          {scoreResult ? (
            <>
              <div style={{ background: "#EEEDFE", borderRadius: "var(--border-radius-md)", padding: "0.75rem", textAlign: "center" }}>
                <div style={{ fontSize: 11, color: "#534AB7", marginBottom: 2 }}>综合评分</div>
                <div style={{ fontSize: 40, fontWeight: 500, color: "#3C3489", lineHeight: 1 }}>{scoreResult.overall}</div>
                <div style={{ fontSize: 11, color: "#7F77DD", marginTop: 4 }}>Band Score</div>
              </div>

              {[
                { key: "fluency",       name: "流利度 Fluency",          color: DIM_COLORS.fluency },
                { key: "lexical",       name: "词汇多样性 Lexical",       color: DIM_COLORS.lexical },
                { key: "grammar",       name: "语法准确度 Grammar",       color: DIM_COLORS.grammar },
                { key: "pronunciation", name: "发音 Pronunciation",      color: DIM_COLORS.pronunciation },
              ].map(({ key, name, color }) => (
                <div key={key}>
                  <ScoreDimBar name={name} score={scoreResult[key]?.score || 0} color={color} />
                  {scoreResult[key]?.tip && (
                    <div style={{ fontSize: 11, color: "var(--color-text-secondary)", marginTop: 3, paddingLeft: 4 }}>
                      → {scoreResult[key].tip}
                    </div>
                  )}
                </div>
              ))}

              {scoreResult.lexical?.suggestions?.length > 0 && (
                <div style={{ background: "#EEEDFE", borderRadius: "var(--border-radius-md)", padding: "0.75rem", fontSize: 12, color: "#26215C", lineHeight: 1.8 }}>
                  <div style={{ fontWeight: 500, marginBottom: 4 }}>表达升级建议</div>
                  {scoreResult.lexical.suggestions.map((s, i) => <div key={i}>• {s}</div>)}
                </div>
              )}

              {scoreResult.grammar?.errors?.length > 0 && (
                <div style={{ background: "#FCEBEB", borderRadius: "var(--border-radius-md)", padding: "0.75rem", fontSize: 12, color: "#4A1B0C", lineHeight: 1.8 }}>
                  <div style={{ fontWeight: 500, marginBottom: 4 }}>语法纠错</div>
                  {scoreResult.grammar.errors.map((e, i) => <div key={i}>• {e}</div>)}
                </div>
              )}
            </>
          ) : (
            <div style={{ fontSize: 12, color: "var(--color-text-tertiary)", lineHeight: 1.8 }}>
              完成至少 3 轮作答后，点击「评分」获取四维分析。
              <br /><br />
              {ttsSupported()
                ? <><i className="ti ti-volume" style={{ marginRight: 4 }} />考官回答会自动朗读</>
                : <><i className="ti ti-info-circle" style={{ marginRight: 4 }} />当前浏览器不支持语音朗读，建议使用 Chrome</>
              }
              <br />
              {asrSupported
                ? <><i className="ti ti-microphone" style={{ marginRight: 4 }} />点麦克风按钮语音作答</>
                : <><i className="ti ti-keyboard" style={{ marginRight: 4 }} />当前浏览器不支持语音识别，请文字作答</>
              }
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function ChatBubble({ message: m }) {
  const isUser = m.role === "user";
  return (
    <div style={{
      maxWidth: "88%",
      alignSelf: isUser ? "flex-end" : "flex-start",
      background: isUser ? "#534AB7" : "#EEEDFE",
      color: isUser ? "#fff" : "#26215C",
      padding: "10px 14px",
      borderRadius: 12,
      borderBottomRightRadius: isUser ? 4 : 12,
      borderBottomLeftRadius: isUser ? 12 : 4,
      fontSize: 13.5, lineHeight: 1.65,
    }}>
      {m.content}
      {m.streaming && <span style={{ opacity: 0.5 }}>▋</span>}
    </div>
  );
}

function SoundWave() {
  return (
    <span style={{ display: "inline-flex", alignItems: "center", gap: 2 }}>
      {[1, 2, 3, 4].map(i => (
        <span key={i} style={{
          display: "inline-block", width: 2, height: 8,
          background: "#534AB7", borderRadius: 1,
          animation: `wave 0.8s ease-in-out ${i * 0.1}s infinite alternate`,
        }} />
      ))}
      <style>{`@keyframes wave{0%{height:3px}100%{height:12px}}`}</style>
    </span>
  );
}

const selectStyle = {
  fontSize: 12, padding: "4px 8px",
  borderRadius: "var(--border-radius-md)",
  border: "0.5px solid var(--color-border-secondary)",
  background: "var(--color-background-secondary)",
  color: "var(--color-text-primary)",
};
